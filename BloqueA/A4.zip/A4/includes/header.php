<!DOCTYPE html>
<html>
  <head>
    <link href="css/styles.css?a=1" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Roboto+Condensed" rel="stylesheet">
  </head>
  <body>
    <header>
      <a href="index.php"><img src="img/logo.png" alt="NeoBank" /></a>
    </header>
    <section>